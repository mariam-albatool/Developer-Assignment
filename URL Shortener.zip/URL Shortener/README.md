#Node.js + MYSql 

## installation


1.UN Zip file , open CMD Terminal from start run this command 'cd Folder_Path_fullPath'.
2.Then run this Command 'npm install' for install all pagekets need to execute the project.
3.Create Database like name of sql file in project folder then Import sql file to MYSql Database.
4.Run Batch file 'app.bat' in project Folder.
5.Open the html page in Your Browser (exampleURLShortener.HTML).


